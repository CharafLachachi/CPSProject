package services;

public enum Dir {
	N,
	S,
	W,
	E
}
