package services;

public enum Command {
	FF,
	BB,
	LL,
	RR,
	TL,
	TR,
	C,
	OPEN,
	CLOSE
}
