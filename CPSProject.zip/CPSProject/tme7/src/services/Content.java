package services;

public enum Content {
	No,
	Yes
}
